package com.example.grade.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity @Table(name="grades",
  uniqueConstraints = @UniqueConstraint(name="uk_student_item", columnNames={"student_id","grade_item_id"}))
@Getter @Setter
public class Grade {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne @JoinColumn(name="student_id")
    private Student student;
    @ManyToOne @JoinColumn(name="grade_item_id")
    private GradeItem gradeItem;
    @Column(nullable=false)
    private Double score;
}
