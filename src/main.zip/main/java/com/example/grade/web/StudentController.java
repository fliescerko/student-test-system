package com.example.grade.web;

import com.example.grade.repo.GradeRepo;
import com.example.grade.repo.StudentRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/student")
@RequiredArgsConstructor
public class StudentController {
    private final StudentRepo studentRepo;
    private final GradeRepo gradeRepo;

    @GetMapping("/grades")
    public String myGrades(@AuthenticationPrincipal UserDetails ud,
                           @RequestParam String term, Model model) {

        var stu = studentRepo.findByUserUsername(ud.getUsername())
                .orElseThrow(() -> new org.springframework.web.server.ResponseStatusException(
                        org.springframework.http.HttpStatus.NOT_FOUND,
                        "No student profile linked to this account"
                ));

        model.addAttribute("term", term);
        model.addAttribute("totals", gradeRepo.computeTotals(stu.getId(), term));
        model.addAttribute("details", gradeRepo.findDetailsByStudentAndTerm(stu.getId(), term));
        return "student/grades";
    }

}

