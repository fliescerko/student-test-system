package com.example.grade.web;

import com.example.grade.model.Course;
import com.example.grade.model.Grade;
import com.example.grade.model.GradeItem;
import com.example.grade.model.Student;
import com.example.grade.repo.CourseRepo;
import com.example.grade.repo.GradeItemRepo;
import com.example.grade.repo.GradeRepo;
import com.example.grade.repo.StudentRepo;
import com.example.grade.service.ImportService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.dao.DataIntegrityViolationException;

@Controller
@RequestMapping("/teacher")
@RequiredArgsConstructor
public class TeacherController {
    private final ImportService importService;
    private final GradeRepo gradeRepo;
    private final StudentRepo studentRepo;
    private final GradeItemRepo gradeItemRepo;
    private final CourseRepo courseRepo;


    @GetMapping("/select-import-method")
    public String selectImportMethod() {
        return "teacher/selectImportMethod"; // templates/teacher/selectImportMethod.html
    }
    // Render the form to input grades
    @GetMapping("/input-grade")
    public String showInputGradeForm(@RequestParam(required = false) Long courseId, Model model) {
        // Always provide course list for the dropdown
        model.addAttribute("courses", courseRepo.findAll());

        Course selectedCourse = null;
        if (courseId != null) {
            selectedCourse = courseRepo.findById(courseId).orElse(null);
        }
        model.addAttribute("selectedCourse", selectedCourse);

        if (selectedCourse != null) {
            // Optional: scope data to the course (recommended)
            // model.addAttribute("students", studentRepo.findByCourseId(courseId));
            // model.addAttribute("gradeItems", gradeItemRepo.findByCourseId(courseId));

            // If you don’t have course-scoped repos yet, keep it global for now:
            model.addAttribute("students", studentRepo.findAll());
            model.addAttribute("gradeItems", gradeItemRepo.findAll());
        } else {
            // Avoid truthy non-null collections that would render the block
            model.addAttribute("students", java.util.Collections.emptyList());
            model.addAttribute("gradeItems", java.util.Collections.emptyList());
        }

        return "teacher/inputGrade";
    }




    @PostMapping("/input-grade")
    public String inputGrade(@RequestParam("studentId") Long studentId,
                             @RequestParam("gradeItemId") Long gradeItemId,
                             @RequestParam("score") Double score,
                             RedirectAttributes ra) {
        Student student = studentRepo.findById(studentId).orElseThrow();
        GradeItem gradeItem = gradeItemRepo.findById(gradeItemId).orElseThrow();

        var existingOpt = gradeRepo.findByStudentAndGradeItem(student, gradeItem);
        try {
            if (existingOpt.isPresent()) {
                var g = existingOpt.get();
                g.setScore(score);
                gradeRepo.save(g);
                ra.addFlashAttribute("msg", "已更新分数（学号: " + student.getStudentNo()
                        + "，项目: " + gradeItem.getName() + "）为 " + score);
            } else {
                var g = new Grade();
                g.setStudent(student);
                g.setGradeItem(gradeItem);
                g.setScore(score);
                gradeRepo.save(g);
                ra.addFlashAttribute("msg", "已新增分数（学号: " + student.getStudentNo()
                        + "，项目: " + gradeItem.getName() + "）为 " + score);
            }
            // Preserve the selected course after redirect (assuming GradeItem belongs to a Course)
            Long courseId = gradeItem.getCourse() != null ? gradeItem.getCourse().getId() : null;
            return courseId != null
                    ? "redirect:/teacher/input-grade?courseId=" + courseId
                    : "redirect:/teacher/input-grade";
        } catch (org.springframework.dao.DataIntegrityViolationException e) {
            ra.addFlashAttribute("msg", "提交冲突，请重试一次。若持续出现，请刷新页面后再操作。");
            return "redirect:/teacher/input-grade";
        }
    }

    @PostMapping("/update-grade")
    public String updateGrade(@RequestParam("studentId") Long studentId,
                              @RequestParam("courseId") Long courseId,
                              @RequestParam("gradeItemId") Long gradeItemId,
                              @RequestParam("score") Double score,
                              RedirectAttributes ra) {
        Student student = studentRepo.findById(studentId).orElseThrow();
        GradeItem gradeItem = gradeItemRepo.findById(gradeItemId).orElseThrow();

        Grade grade = gradeRepo.findByStudentAndGradeItem(student, gradeItem)
                .orElseThrow(() -> new IllegalArgumentException("Grade not found"));

        grade.setScore(score);
        gradeRepo.save(grade);

        ra.addFlashAttribute("msg", "Grade successfully updated for " + student.getFullName());
        return "redirect:/teacher/input-grade?courseId=" + courseId; // keep context
    }


    @GetMapping("/upload")
    public String page() { return "teacher/upload"; } // templates/teacher/upload.html

    @PostMapping("/grades/import")
    public String importCsv(@RequestParam("file") MultipartFile file,
                            RedirectAttributes ra) {
        var r = importService.importCsv(file);
        ra.addFlashAttribute("msg", "导入完成：成功 " + r.success() + " 行，失败 " + r.fail() + " 行");
        return "redirect:/teacher/upload";
    }
}


