package com.example.grade.config;

import com.example.grade.model.*;
import com.example.grade.repo.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.*;

@Configuration
public class DataInit {

    @Bean
    CommandLineRunner seedData(
            UserRepo userRepo,
            TeacherRepo teacherRepo,
            StudentRepo studentRepo,
            CourseRepo courseRepo,
            GradeItemRepo gradeItemRepo,
            GradeRepo gradeRepo,
            PasswordEncoder encoder
    ) {
        return args -> {
            // ---- 1️⃣ 用户初始化 ----
            List<User> users = new ArrayList<>();

            // 管理员
            users.add(createUser(userRepo, encoder, "admin", "ADMIN", "admin@example.com"));

            // 教师
            for (int i = 1; i <= 3; i++) {
                users.add(createUser(userRepo, encoder, "teacher" + i, "TEACHER", "teacher" + i + "@example.com"));
            }

            // 学生
            for (int i = 1; i <= 10; i++) {
                users.add(createUser(userRepo, encoder, "student" + i, "STUDENT", "student" + i + "@example.com"));
            }

            // ---- 2️⃣ 教师表（优化部分）----
            List<Teacher> teachers = new ArrayList<>();
            // 为每个教师添加"查询不存在则插入"的逻辑
            addTeacherIfNotExists(teachers, teacherRepo, "张老师", "T001", userRepo.findByUsername("teacher1").orElseThrow());
            addTeacherIfNotExists(teachers, teacherRepo, "李老师", "T002", userRepo.findByUsername("teacher2").orElseThrow());
            addTeacherIfNotExists(teachers, teacherRepo, "王老师", "T003", userRepo.findByUsername("teacher3").orElseThrow());
            if (!teachers.isEmpty()) { // 只有当列表有新数据时才执行保存
                teacherRepo.saveAll(teachers);
            }

            // ---- 3️⃣ 学生表（同样优化，避免重复）----
            List<Student> students = new ArrayList<>();
            for (int i = 1; i <= 10; i++) {
                String studentNo = "S00" + i;
                // 检查学生编号是否已存在
                if (studentRepo.findByStudentNo(studentNo).isEmpty()) {
                    students.add(newStudent("学生" + i, studentNo, userRepo.findByUsername("student" + i).orElseThrow()));
                }
            }
            if (!students.isEmpty()) {
                studentRepo.saveAll(students);
            }

            // ---- 4️⃣ 课程（优化）----
            List<Course> courses = new ArrayList<>();
            addCourseIfNotExists(courses, courseRepo, "CHN101", "语文", "2025秋");
            addCourseIfNotExists(courses, courseRepo, "MAT101", "数学", "2025秋");
            addCourseIfNotExists(courses, courseRepo, "ENG101", "英语", "2025秋");
            addCourseIfNotExists(courses, courseRepo, "SCI101", "科学", "2025秋");
            if (!courses.isEmpty()) {
                courseRepo.saveAll(courses);
            }

            // ---- 5️⃣ 成绩项（优化）----
            List<GradeItem> gradeItems = new ArrayList<>();
            for (Course c : courses) {
                // 检查同一课程下是否已存在同名成绩项
                if (gradeItemRepo.findByCourseAndName(c, "平时成绩").isEmpty()) {
                    GradeItem normal = new GradeItem();
                    normal.setCourse(c);
                    normal.setName("平时成绩");
                    normal.setWeight(40);
                    normal.setIsFinal(false);
                    gradeItems.add(normal);
                }

                if (gradeItemRepo.findByCourseAndName(c, "期末成绩").isEmpty()) {
                    GradeItem finalExam = new GradeItem();
                    finalExam.setCourse(c);
                    finalExam.setName("期末成绩");
                    finalExam.setWeight(60);
                    finalExam.setIsFinal(true);
                    gradeItems.add(finalExam);
                }
            }
            if (!gradeItems.isEmpty()) {
                gradeItemRepo.saveAll(gradeItems);
            }

            // ---- 6️⃣ 成绩（优化）----
            Random random = new Random();
            List<Grade> grades = new ArrayList<>();
            // 先获取所有已存在的成绩项（避免使用刚插入的可能未刷新的列表）
            List<GradeItem> existingGradeItems = gradeItemRepo.findAll();

            for (Student s : students) {
                for (GradeItem item : existingGradeItems) {
                    // 检查学生在该成绩项上是否已有成绩
                    if (gradeRepo.findByStudentAndGradeItem(s, item).isEmpty()) {
                        Grade g = new Grade();
                        g.setStudent(s);
                        g.setGradeItem(item);
                        g.setScore(60.0 + random.nextInt(41)); // 60–100随机
                        grades.add(g);
                    }
                }
            }
            if (!grades.isEmpty()) {
                gradeRepo.saveAll(grades);
            }

            System.out.println("✅ 测试数据初始化完成：");
            System.out.println("教师数量: " + teacherRepo.count());
            System.out.println("学生数量: " + studentRepo.count());
            System.out.println("课程数量: " + courseRepo.count());
            System.out.println("成绩数量: " + gradeRepo.count());
        };
    }

    // 工具方法：教师不存在则添加
    private void addTeacherIfNotExists(List<Teacher> teachers, TeacherRepo repo, String fullName, String no, User user) {
        if (repo.findByTeacherNo(no).isEmpty()) {
            teachers.add(newTeacher(fullName, no, user));
        }
    }

    // 工具方法：课程不存在则添加
    private void addCourseIfNotExists(List<Course> courses, CourseRepo repo, String code, String name, String term) {
        if (repo.findByCode(code).isEmpty()) {
            courses.add(newCourse(code, name, term));
        }
    }

    // 原有工具方法保持不变
    private User createUser(UserRepo repo, PasswordEncoder encoder, String username, String role, String email) {
        return repo.findByUsername(username)
                .orElseGet(() -> {
                    User u = new User();
                    u.setUsername(username);
                    u.setPasswordHash(encoder.encode("password"));
                    u.setEmail(email);
                    u.setRole(role);
                    u.setActive(true);
                    return repo.save(u);
                });
    }

    private Teacher newTeacher(String fullName, String no, User user) {
        Teacher t = new Teacher();
        t.setFullName(fullName);
        t.setTeacherNo(no);
        t.setUser(user);
        return t;
    }

    private Student newStudent(String fullName, String no, User user) {
        Student s = new Student();
        s.setFullName(fullName);
        s.setStudentNo(no);
        s.setUser(user);
        return s;
    }

    private Course newCourse(String code, String name, String term) {
        Course c = new Course();
        c.setCode(code);
        c.setName(name);
        c.setTerm(term);
        return c;
    }
}