package com.example.grade.service;
import com.example.grade.model.Course;
import com.example.grade.model.Grade;
import com.example.grade.model.GradeItem;
import com.example.grade.repo.CourseRepo;
import com.example.grade.repo.GradeItemRepo;
import com.example.grade.repo.GradeRepo;
import com.example.grade.repo.StudentRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

@Service
@RequiredArgsConstructor
public class ImportService {
    private final StudentRepo studentRepo; private final CourseRepo courseRepo;
    private final GradeItemRepo gradeItemRepo; private final GradeRepo gradeRepo;

    @Transactional
    public ImportResult importCsv(MultipartFile file) {
        int ok=0, fail=0;
        try (var br = new BufferedReader(new InputStreamReader(file.getInputStream(), StandardCharsets.UTF_8))) {
            var parser = CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).build().parse(br);
            for (var r : parser) try {
                var stuNo = r.get("studentNo").trim();
                var code  = r.get("courseCode").trim();
                var term  = r.get("term").trim();
                var item  = r.get("itemName").trim();
                var weight= Integer.valueOf(r.get("weight").trim());
                var score = Double.valueOf(r.get("score").trim());

                var student = studentRepo.findByStudentNo(stuNo)
                        .orElseThrow(() -> new IllegalArgumentException("学生不存在:"+stuNo));
                var course = courseRepo.findByCodeAndTerm(code, term)
                        .orElseGet(() -> { var c=new Course(); c.setCode(code); c.setTerm(term); c.setName(code); return courseRepo.save(c); });
                var gi = gradeItemRepo.findByCourseIdAndName(course.getId(), item)
                        .orElseGet(() -> { var x=new GradeItem(); x.setCourse(course); x.setName(item); x.setWeight(weight); x.setIsFinal(false); return gradeItemRepo.save(x); });

                // upsert：学生 x 评分项 唯一
                var grade = gradeRepo.findByStudentAndGradeItem(student, gi)
                        .orElseGet(Grade::new);   // 无参构造

                grade.setStudent(student);
                grade.setGradeItem(gi);
                grade.setScore(score);

                gradeRepo.save(grade);

            } catch (Exception e){ fail++; }
        } catch (IOException e){ throw new RuntimeException(e); }
        return new ImportResult(ok, fail);
    }
    public record ImportResult(int success, int fail){}
}
